package br.com.inacioalves.mc.orders_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
